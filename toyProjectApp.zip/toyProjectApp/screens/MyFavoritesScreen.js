import { Text } from "react-native"



function MyFavoritesScreen(){
    return(
        <Text>즐겨찾기 화면</Text>
    )

}

export default MyFavoritesScreen
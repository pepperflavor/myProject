import { View } from "react-native";


function Profile(){
    return(
        <View>
            
        </View>
    )

}
export default Profile;
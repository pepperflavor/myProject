class BasicMenu{
    constructor(id, categoryIds, title, body, imageUrl, explanation){
        this.id = id;
        this.categoryIds = categoryIds;
        this.title = title;
        this.body = body;
        this.imageUrl = imageUrl;
        this.explanation = explanation;
    }
}

export default BasicMenu
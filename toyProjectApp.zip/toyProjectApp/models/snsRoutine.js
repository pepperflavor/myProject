class SnsRoutine {
  constructor(id, nickname, category, title, amount, sets, comment,date) {
    this.id = id;
    this.nickname = nickname;
    this.category = category;
    this.title = title;
    this.amount = amount;
    this.sets = sets;
    this.comment = comment;
    this.date = date;
  }
}

export default SnsRoutine;